package pages;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
public class MyInfoPersonalDetails {
	WebDriver driver;
	Actions act ;
	@FindBy(name = "username")
	WebElement Name1;

	@FindBy(name = "password")
	WebElement Pass;

	@FindBy(xpath = "//button[@type='submit']")
	WebElement clickk;
	public MyInfoPersonalDetails(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver,this);
		 act = new Actions(driver);
	}
	
	@FindBy(xpath = "//body/div[@id='app']/div[@class='oxd-layout']/div[@class='oxd-layout-navigation']/aside[@class='oxd-sidepanel']/nav[@class='oxd-navbar-nav']/div[@class='oxd-sidepanel-body']/ul[@class='oxd-main-menu']/li[6]/a[1]")
	WebElement click_1;

	public void click1()
	{
		click_1.click();
	}

	@FindBy(xpath = "//a[contains(text(),'Personal Details')]")
	WebElement click_2;

	public void click2()
	{
		click_2.click();
	}

	

	@FindBy(how=How.CSS,using = "input[placeholder='First Name']")
	WebElement Fname;

	public void firstname(String f_name) throws Exception
	{
		Thread.sleep(2000);
		Fname.sendKeys(Keys.chord(Keys.CONTROL, "a"),f_name);
	}
	//MIDDLE NAME
	@FindBy(how=How.CSS,using = "input[placeholder='Middle Name']")
	WebElement Mname;
	
	public void middlename(String mid_name) throws Exception
	{
		Thread.sleep(2000);
		Mname.sendKeys(Keys.chord(Keys.CONTROL, "a"),mid_name);
	}

	//LAST NAME
	@FindBy(how=How.CSS,using = "input[placeholder='Last Name']")
	WebElement Lname;
	
	public void lastname(String l_name) throws Exception
	{
		Thread.sleep(2000);
		Lname.sendKeys(Keys.chord(Keys.CONTROL, "a"),l_name);
	}

	@FindBy(xpath = "//body[1]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[2]/div[1]/form[1]/div[1]/div[2]/div[1]/div[1]/div[2]/input[1]")
	WebElement nick;
	
	public void nickname(String n_name)
	{
		nick.sendKeys(Keys.chord(Keys.CONTROL, "a"),n_name);
	}

	@FindBy(xpath = "//body/div[@id='app']/div[@class='oxd-layout']/div[@class='oxd-layout-container']/div[@class='oxd-layout-context']/div[@class='orangehrm-background-container']/div[@class='orangehrm-card-container']/div[@class='orangehrm-edit-employee']/div[@class='orangehrm-edit-employee-content']/div[@class='orangehrm-horizontal-padding orangehrm-vertical-padding']/form[@class='oxd-form']/div[2]/div[1]/div[1]/div[1]/div[2]/input[1]")
	WebElement emp_id;
	
	public void employee_id(String e_id)
	{
		emp_id.sendKeys(Keys.chord(Keys.CONTROL, "a"),e_id);
	}

	@FindBy(xpath = "//body/div[@id='app']/div[@class='oxd-layout']/div[@class='oxd-layout-container']/div[@class='oxd-layout-context']/div[@class='orangehrm-background-container']/div[@class='orangehrm-card-container']/div[@class='orangehrm-edit-employee']/div[@class='orangehrm-edit-employee-content']/div[@class='orangehrm-horizontal-padding orangehrm-vertical-padding']/form[@class='oxd-form']/div[@class='oxd-form-row']/div[1]/div[2]/div[1]/div[2]/input[1]")
	WebElement oth_id;
	
	public void other_id(String o_id)
	{
		oth_id.sendKeys(Keys.chord(Keys.CONTROL, "a"),o_id);
	}

	@FindBy(xpath = "//body/div[@id='app']/div[@class='oxd-layout']/div[@class='oxd-layout-container']/div[@class='oxd-layout-context']/div[@class='orangehrm-background-container']/div[@class='orangehrm-card-container']/div[@class='orangehrm-edit-employee']/div[@class='orangehrm-edit-employee-content']/div[@class='orangehrm-horizontal-padding orangehrm-vertical-padding']/form[@class='oxd-form']/div[2]/div[2]/div[1]/div[1]/div[2]/input[1]")
	WebElement lis;
	
	public void lisence(String li_no)
	{
		lis.sendKeys(Keys.chord(Keys.CONTROL, "a"),li_no);
	}
	 
	@FindBy(xpath = "//body/div[@id='app']/div[@class='oxd-layout']/div[@class='oxd-layout-container']/div[@class='oxd-layout-context']/div[@class='orangehrm-background-container']/div[@class='orangehrm-card-container']/div[@class='orangehrm-edit-employee']/div[@class='orangehrm-edit-employee-content']/div[@class='orangehrm-horizontal-padding orangehrm-vertical-padding']/form[@class='oxd-form']/div[@class='oxd-form-row']/div[3]/div[1]/div[1]/div[2]/input[1]")
	WebElement ssn;
	
	public void ssn_no(String ssn_n)
	{
		ssn.sendKeys(Keys.chord(Keys.CONTROL, "a"),ssn_n);
	}
	
	@FindBy(xpath = "//body/div[@id='app']/div[@class='oxd-layout']/div[@class='oxd-layout-container']/div[@class='oxd-layout-context']/div[@class='orangehrm-background-container']/div[@class='orangehrm-card-container']/div[@class='orangehrm-edit-employee']/div[@class='orangehrm-edit-employee-content']/div[@class='orangehrm-horizontal-padding orangehrm-vertical-padding']/form[@class='oxd-form']/div[@class='oxd-form-row']/div[3]/div[2]/div[1]/div[2]/input[1]")
	WebElement sin;
	
	public void sin_no(String sin_n)
	{
		sin.sendKeys(Keys.chord(Keys.CONTROL, "a"),sin_n);
	}

	@FindBy(xpath = "//body/div[@id='app']/div[@class='oxd-layout']/div[@class='oxd-layout-container']/div[@class='oxd-layout-context']/div[@class='orangehrm-background-container']/div[@class='orangehrm-card-container']/div[@class='orangehrm-edit-employee']/div[@class='orangehrm-edit-employee-content']/div[@class='orangehrm-horizontal-padding orangehrm-vertical-padding']/form[@class='oxd-form']/div[2]/div[2]/div[1]/div[1]/div[2]/input[1]")
	WebElement nat;
	

	public void nationality()
	{
		nat.click();
		act.sendKeys(Keys.ARROW_DOWN).build().perform();
		act.sendKeys(Keys.ARROW_DOWN).build().perform();
		act.sendKeys(Keys.ENTER).build().perform();  
	}


	@FindBy(xpath = "//body/div[@id='app']/div[@class='oxd-layout']/div[@class='oxd-layout-container']/div[@class='oxd-layout-context']/div[@class='orangehrm-background-container']/div[@class='orangehrm-card-container']/div[@class='orangehrm-edit-employee']/div[@class='orangehrm-edit-employee-content']/div[@class='orangehrm-horizontal-padding orangehrm-vertical-padding']/form[@class='oxd-form']/div[@class='oxd-form-row']/div[@class='oxd-grid-3 orangehrm-full-width-grid']/div[2]/div[1]/div[2]/div[1]/div[1]/div[2]/i[1]")
	WebElement ms;
	
	public void mar_status()
	{
		ms.click();
		act.sendKeys(Keys.ARROW_DOWN);
		act.sendKeys(Keys.ENTER).build().perform();  
	}

	@FindBy(xpath = "//body/div[@id='app']/div[@class='oxd-layout']/div[@class='oxd-layout-container']/div[@class='oxd-layout-context']/div[@class='orangehrm-background-container']/div[@class='orangehrm-card-container']/div[@class='orangehrm-edit-employee']/div[@class='orangehrm-edit-employee-content']/div[@class='orangehrm-horizontal-padding orangehrm-vertical-padding']/form[@class='oxd-form']/div[4]/div[1]/div[1]/div[1]/div[2]/input[1]")
	WebElement mls;
	
	public void malli_status(String ml_no)
	{
		mls.sendKeys(Keys.chord(Keys.CONTROL, "a"),ml_no);
	}

	@FindBy(xpath = "//label[text()='Yes']")
	WebElement click_3;

	public void click3()
	{
		click_3.click();
	}

	@FindBy(xpath = "//body/div[@id='app']/div[@class='oxd-layout']/div[@class='oxd-layout-container']/div[@class='oxd-layout-context']/div[@class='orangehrm-background-container']/div[@class='orangehrm-card-container']/div[@class='orangehrm-edit-employee']/div[@class='orangehrm-edit-employee-content']/div[@class='orangehrm-horizontal-padding orangehrm-vertical-padding']/form[@class='oxd-form']/div[@class='oxd-form-actions']/button[1]")
	WebElement click_4;

	public void click4()
	{
		click_4.click();
	}

	@FindBy(xpath = "//div[@class='orangehrm-custom-fields']//div[@class='orangehrm-card-container']//form[@class='oxd-form']//div[@class='oxd-form-row']//div[@class='oxd-grid-3 orangehrm-full-width-grid']//div[@class='oxd-grid-item oxd-grid-item--gutters']//div[@class='oxd-input-group oxd-input-field-bottom-space']//div//div[@class='oxd-select-wrapper']//div[@class='oxd-select-text oxd-select-text--active']//div[@class='oxd-select-text--after']//i[@class='oxd-icon bi-caret-down-fill oxd-select-text--arrow']")
	WebElement cf;
	
//	public void custom_field()
//	{
//		cf.click();
//		act.sendKeys(Keys.ARROW_DOWN);
//		act.sendKeys(Keys.ARROW_DOWN);
//		act.sendKeys(Keys.ENTER).build().perform();  
//	}


	@FindBy(xpath = "//body/div[@id='app']/div[@class='oxd-layout']/div[@class='oxd-layout-container']/div[@class='oxd-layout-context']/div[@class='orangehrm-background-container']/div[@class='orangehrm-card-container']/div[@class='orangehrm-edit-employee']/div[@class='orangehrm-edit-employee-content']/div[@class='orangehrm-custom-fields']/div[@class='orangehrm-card-container']/form[@class='oxd-form']/div[@class='oxd-form-actions']/button[1]")
	WebElement click_5;

	public void click5()
	{
		click_5.click();

	}
	@FindBy(how=How.XPATH,using="//div[@class='orangehrm-horizontal-padding orangehrm-vertical-padding']//button[@type='submit'][normalize-space()='Save']")
	WebElement saveBtn;
	public void saveButton()
	{
		saveBtn.click();

	}

}