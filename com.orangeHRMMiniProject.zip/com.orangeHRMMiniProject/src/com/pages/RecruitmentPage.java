package pages;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class RecruitmentPage {
	
	
	WebDriver driver;
	Actions A;

	@FindBy(name = "username")
	WebElement Name1;
	 
	@FindBy(name = "password")
	WebElement Pass;

	@FindBy(css = "div.orangehrm-login-layout div.orangehrm-login-layout-blob div.orangehrm-login-container div.orangehrm-login-slot-wrapper div.orangehrm-login-slot div.orangehrm-login-form form.oxd-form:nth-child(2) div.oxd-form-actions.orangehrm-login-action:nth-child(4) > button.oxd-button.oxd-button--medium.oxd-button--main.orangehrm-login-button")
	WebElement click;
     
	@FindBy(xpath = "//span[text()='Recruitment']")
	WebElement click_recruit;

	@FindBy(xpath = "//a[contains(text(),'Candidates')]")
	WebElement click_candidate;
	
	@FindBy(xpath = "//a[contains(text(),'Vacancies')]")
	WebElement click_vacancy;

	
	//a[contains(text(),'Vacancies')]
	                 
	@FindBy(xpath = "//body/div[@id='app']/div[@class='oxd-layout']/div[@class='oxd-layout-container']/div[@class='oxd-layout-context']/div[@class='orangehrm-candidate-page']/div[@class='oxd-table-filter']/div[@class='oxd-table-filter-area']/form[@class='oxd-form']/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[2]/i[1]")
	WebElement jobTitle;
	 
	@FindBy(xpath = "//body/div[@id='app']/div[@class='oxd-layout']/div[@class='oxd-layout-container']/div[@class='oxd-layout-context']/div[@class='orangehrm-candidate-page']/div[@class='oxd-table-filter']/div[@class='oxd-table-filter-area']/form[@class='oxd-form']/div[@class='oxd-form-row']/div[@class='oxd-grid-4 orangehrm-full-width-grid']/div[2]/div[1]/div[2]/div[1]/div[1]/div[1]")
	WebElement vacancy;

	@FindBy(xpath = "//body/div[@id='app']/div[@class='oxd-layout']/div[@class='oxd-layout-container']/div[@class='oxd-layout-context']/div[@class='orangehrm-candidate-page']/div[@class='oxd-table-filter']/div[@class='oxd-table-filter-area']/form[@class='oxd-form']/div[@class='oxd-form-row']/div[@class='oxd-grid-4 orangehrm-full-width-grid']/div[3]/div[1]/div[2]/div[1]/div[1]/div[1]")
	WebElement HiringMananger;
	 
	@FindBy(xpath = "//body/div[@id='app']/div[@class='oxd-layout']/div[@class='oxd-layout-container']/div[@class='oxd-layout-context']/div[@class='orangehrm-candidate-page']/div[@class='oxd-table-filter']/div[@class='oxd-table-filter-area']/form[@class='oxd-form']/div[@class='oxd-form-row']/div[@class='oxd-grid-4 orangehrm-full-width-grid']/div[3]/div[1]/div[2]/div[1]/div[1]/div[1]")
	WebElement status;
	
	@FindBy(xpath = "//input[@placeholder='Type for hints...']")
	WebElement CandidateName;
	 
	@FindBy(xpath = "//body/div[@id='app']/div[@class='oxd-layout']/div[@class='oxd-layout-container']/div[@class='oxd-layout-context']/div[@class='orangehrm-candidate-page']/div[@class='oxd-table-filter']/div[@class='oxd-table-filter-area']/form[@class='oxd-form']/div[@class='oxd-form-row']/div[@class='oxd-grid-4 orangehrm-full-width-grid']/div[@class='oxd-grid-item oxd-grid-item--gutters']/div[@class='oxd-input-group oxd-input-field-bottom-space']/div/input[1]")
	WebElement Keywords;

	
	@FindBy(xpath = "//body/div[@id='app']/div[@class='oxd-layout']/div[@class='oxd-layout-container']/div[@class='oxd-layout-context']/div[@class='orangehrm-candidate-page']/div[@class='oxd-table-filter']/div[@class='oxd-table-filter-area']/form[@class='oxd-form']/div[@class='oxd-form-row']/div[@class='oxd-grid-4 orangehrm-full-width-grid']/div[3]/div[1]/div[2]/div[1]/div[1]/input[1]")
	WebElement dateOfApplication;
	
	@FindBy(xpath = "//body/div[@id='app']/div[@class='oxd-layout']/div[@class='oxd-layout-container']/div[@class='oxd-layout-context']/div[@class='orangehrm-candidate-page']/div[@class='oxd-table-filter']/div[@class='oxd-table-filter-area']/form[@class='oxd-form']/div[@class='oxd-form-row']/div[@class='oxd-grid-4 orangehrm-full-width-grid']/div[4]/div[1]/div[2]/div[1]/div[1]/i[1]")
	WebElement to;
	
	@FindBy(xpath = "//body/div[@id='app']/div[@class='oxd-layout']/div[@class='oxd-layout-container']/div[@class='oxd-layout-context']/div[@class='orangehrm-candidate-page']/div[@class='oxd-table-filter']/div[@class='oxd-table-filter-area']/form[@class='oxd-form']/div[3]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[2]/i[1]")
	WebElement methodOfApplication;
	
	@FindBy(xpath = "//button[@type='submit']")
	WebElement submit;
	
	@FindBy(xpath = "//body/div[@id='app']/div[@class='oxd-layout']/div[@class='oxd-layout-container']/div[@class='oxd-layout-context']/div[@class='orangehrm-background-container']/div[@class='oxd-table-filter']/div[@class='oxd-table-filter-area']/form[@class='oxd-form']/div[@class='oxd-form-row']/div[@class='oxd-grid-4 orangehrm-full-width-grid']/div[1]/div[1]/div[2]/div[1]/div[1]/div[2]/i[1]")
	WebElement vac_jobTitle;
	 
	@FindBy(xpath = "//body/div[@id='app']/div[@class='oxd-layout']/div[@class='oxd-layout-container']/div[@class='oxd-layout-context']/div[@class='orangehrm-background-container']/div[@class='oxd-table-filter']/div[@class='oxd-table-filter-area']/form[@class='oxd-form']/div[@class='oxd-form-row']/div[@class='oxd-grid-4 orangehrm-full-width-grid']/div[2]/div[1]/div[2]/div[1]/div[1]/div[2]/i[1]")
	WebElement vac_vacancy;

	@FindBy(xpath = "//body/div[@id='app']/div[@class='oxd-layout']/div[@class='oxd-layout-container']/div[@class='oxd-layout-context']/div[@class='orangehrm-background-container']/div[@class='oxd-table-filter']/div[@class='oxd-table-filter-area']/form[@class='oxd-form']/div[@class='oxd-form-row']/div[@class='oxd-grid-4 orangehrm-full-width-grid']/div[3]/div[1]/div[2]/div[1]/div[1]/div[2]/i[1]")
	WebElement vac_HiringMananger;
	 
	@FindBy(xpath = "//body/div[@id='app']/div[@class='oxd-layout']/div[@class='oxd-layout-container']/div[@class='oxd-layout-context']/div[@class='orangehrm-background-container']/div[@class='oxd-table-filter']/div[@class='oxd-table-filter-area']/form[@class='oxd-form']/div[@class='oxd-form-row']/div[@class='oxd-grid-4 orangehrm-full-width-grid']/div[4]/div[1]/div[2]/div[1]/div[1]/div[2]/i[1]")
	WebElement vac_status;

	@FindBy(xpath = "//button[@type='submit']")
	WebElement vac_submit;


	public RecruitmentPage(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver,this);
		A=new Actions(driver);
	}


	
	public void candidate(String name,String key) throws InterruptedException
	{
			click_recruit.click();
			click_candidate.click();
				
			jobTitle.click();
			
		  jobTitle.click();
		  Thread.sleep(3000);
		  A.sendKeys(Keys.ARROW_DOWN);
		  A.sendKeys(Keys.ARROW_DOWN);
		  A.sendKeys(Keys.ENTER).build().perform();  
		  
		  vacancy.click();
		  Thread.sleep(2000);
		  A.sendKeys(Keys.ARROW_DOWN);
		  A.sendKeys(Keys.ARROW_DOWN);
		  A.sendKeys(Keys.ENTER).build().perform();  

		  HiringMananger.click();
		  Thread.sleep(3000);
		  A.sendKeys(Keys.ARROW_DOWN);
		  A.sendKeys(Keys.ARROW_DOWN);
		  A.sendKeys(Keys.ENTER).build().perform();  
			Thread.sleep(5000);

		  status.click();
		 Thread.sleep(3000);
		  A.sendKeys(Keys.ARROW_DOWN);
		  A.sendKeys(Keys.ARROW_DOWN);
		  A.sendKeys(Keys.ENTER).build().perform();  

		  CandidateName.sendKeys(name);

		  Keywords.sendKeys(key);
		  
		  dateOfApplication.click();
		  dateOfApplication.sendKeys("2022-10-21");
		  
		  //to.click();
		  //to.sendKeys("2022-10-31");
		  
		  methodOfApplication.click();
		  Thread.sleep(3000);
		  A.sendKeys(Keys.ARROW_DOWN);
		  A.sendKeys(Keys.ENTER).build().perform();  
		  
		  submit.click();
		  
		  click_recruit.click();
		  
		  click_vacancy.click();
		  
		  vac_jobTitle.click();
			 Thread.sleep(3000);
			  A.sendKeys(Keys.ARROW_DOWN);
			  A.sendKeys(Keys.ARROW_DOWN);
			  A.sendKeys(Keys.ENTER).build().perform();  
	  
		  vac_vacancy.click();
			 Thread.sleep(3000);
			  A.sendKeys(Keys.ARROW_DOWN);
			  A.sendKeys(Keys.ARROW_DOWN);
			  A.sendKeys(Keys.ENTER).build().perform();  

		  vac_HiringMananger.click();
			 Thread.sleep(3000);
			  A.sendKeys(Keys.ARROW_DOWN);
			  A.sendKeys(Keys.ARROW_DOWN);
			  A.sendKeys(Keys.ENTER).build().perform();  

		  vac_status.click();
			 Thread.sleep(3000);
			  A.sendKeys(Keys.ARROW_DOWN);
			  A.sendKeys(Keys.ARROW_DOWN);
			  A.sendKeys(Keys.ENTER).build().perform();  

		  vac_submit.click();

	}

}
