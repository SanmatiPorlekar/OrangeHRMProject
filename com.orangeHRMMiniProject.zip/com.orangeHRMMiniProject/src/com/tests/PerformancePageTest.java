package tests;
import java.io.IOException;
import java.util.Arrays;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pages.LoginPage;
import pages.PIMPage;
import pages.LeavePage;
import pages.TimePage;
import utils.ShipmentTest;
import utils.TakeScreenShot;
import pages.PerformancePage;
import io.github.bonigarcia.wdm.WebDriverManager;
import utils.WebDriverPage;

public class PerformancePageTest {
	WebDriver driver;
	PIMPage pimSection;
	LoginPage loginSection;
	LeavePage leaveSection;
	TimePage timeSection;
	PerformancePage performanceSection;
	ShipmentTest ship;
	WebDriverPage wbPageSection;
	TakeScreenShot scsht;
	String[][] loginData;
	
	Logger logger = LogManager.getLogger(PerformancePageTest.class.getName());

	@BeforeTest
	public void setUp() throws InvalidFormatException, IOException {
		wbPageSection=new WebDriverPage(driver);
		driver=wbPageSection.setBrowser("chrome");
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		pimSection = new PIMPage(driver);
		loginSection = new LoginPage(driver);
		leaveSection = new LeavePage(driver);
		timeSection = new TimePage(driver);
		performanceSection = new PerformancePage(driver);
		ship = new ShipmentTest();
		scsht = new TakeScreenShot();
		loginData = ship.getData();
		// System.out.println(Arrays.deepToString(loginData));
		loginSection.setLoginPageUsrName(loginData[0][0]);
		loginSection.setLoginPagePassword(loginData[0][1]);
		loginSection.clickLoginPageLoginBtn();
		logger.info("Login Completed");

	}

	@Test(priority = 1)
	public void performanceSec() throws Exception {
		
		performanceSection.performanceClick();
	//	Thread.sleep(2000);	
		performanceSection.eName();
	//	Thread.sleep(2000);
		performanceSection.myTrackers(loginData[20][0],loginData[20][1]);
		logger.info("Performance section is completed");
	}
	@AfterTest
	public void tearDown() {
	driver.quit();
}

	
}
