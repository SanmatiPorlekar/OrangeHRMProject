package tests;



import java.io.IOException;
//import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeUnit;

import org.apache.commons.compress.archivers.dump.InvalidFormatException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
import pages.MyInfoPersonalDetails;
import utils.ShipmentTest;
import pages.MyInfoContactDetails;
import pages.*;
import utils.ShipmentTest;
import utils.WebDriverPage;
@Test
public class MyInfoPageTest {
		WebDriver driver;
		MyInfoContactDetails myInfoContactSection;
		MyInfoPersonalDetails myInfoPersonalDetailSection;
		LoginPage loginSection; 
		ShipmentTest ship;
		String[][] loginData;
		WebDriverPage wbPageSection;
		public static String url = "https://opensource-demo.orangehrmlive.com/web/index.php/auth/login";
		Logger logger = LogManager.getLogger(MyInfoPageTest.class.getName());
@BeforeTest
public void driverSetUp()throws Exception{	
	logger.info("SetUp Started");
	wbPageSection=new WebDriverPage(driver);
	driver=wbPageSection.setBrowser("chrome");
	driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
	myInfoContactSection = new MyInfoContactDetails(driver);
	myInfoPersonalDetailSection = new MyInfoPersonalDetails(driver); 
	loginSection=new LoginPage(driver);
	ship=new ShipmentTest();
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	loginData=ship.getData();
	loginSection.setLoginPageUsrName(loginData[0][0]);
	loginSection.setLoginPagePassword(loginData[0][1]);
	loginSection.clickLoginPageLoginBtn();

}	
@Test(priority=1)
public void myInfoSec() throws Exception{
	//methods called for personal details module
	logger.info("Personal Information is started");
	myInfoPersonalDetailSection.click1();
	myInfoPersonalDetailSection.click2();
	myInfoPersonalDetailSection.firstname(loginData[15][0]);
	myInfoPersonalDetailSection.middlename(loginData[15][1]);
	myInfoPersonalDetailSection.lastname(loginData[15][2]);
	myInfoPersonalDetailSection.nickname(loginData[15][3]);
	myInfoPersonalDetailSection.employee_id(loginData[15][4]);
	myInfoPersonalDetailSection.other_id(loginData[15][5]);
	myInfoPersonalDetailSection.lisence(loginData[15][6]);
	myInfoPersonalDetailSection.ssn_no(loginData[15][7]);
	myInfoPersonalDetailSection.sin_no(loginData[15][8]);
	myInfoPersonalDetailSection.saveButton();
	logger.info("Personal Information is completed");

}
@Test(priority=2)
public void myInfoContactDetails() {
	//methods called for contact details module
	logger.info("contact details is started");
	myInfoContactSection.click1();
	myInfoContactSection.click2();
	myInfoContactSection.street1(loginData[16][0]);
	myInfoContactSection.street2(loginData[16][1]);
	myInfoContactSection.city(loginData[16][2]);
	myInfoContactSection.state(loginData[16][3]);
	myInfoContactSection.zip(loginData[16][4]);
	myInfoContactSection.country();
	myInfoContactSection.home(loginData[16][5]);
	myInfoContactSection.mobile(loginData[16][6]);
	myInfoContactSection.work(loginData[16][7]);
	myInfoContactSection.email(loginData[16][8]);
	myInfoContactSection.o_email(loginData[16][9]);
	myInfoContactSection.clickLast();
	logger.info("contact details is completed");

}

@AfterTest
public void tearDown()
{
	driver.quit();
}
}
