package tests;

import java.io.IOException;
import utils.WebDriverPage;
import java.util.concurrent.TimeUnit;

import org.apache.commons.compress.archivers.dump.InvalidFormatException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
import pages.LoginPage;
import pages.RecruitmentPage;
import utils.ShipmentTest;
import utils.TakeScreenShot;
import pages.*;
public class RecruitmentPageTest {
WebDriver driver;
RecruitmentPage R;
LoginPage loginSection;
ShipmentTest ship;
String[][] loginData;
WebDriverPage wbPageSection;
TakeScreenShot scsht;
public static String url = "https://opensource-demo.orangehrmlive.com/web/index.php/auth/login";
Logger logger = LogManager.getLogger(RecruitmentPageTest.class.getName());
@BeforeTest
public void driverSetUp()throws Exception

{	
	
	wbPageSection=new WebDriverPage(driver);
	driver=wbPageSection.setBrowser("chrome");
	driver.get(url);
	loginSection=new LoginPage(driver);
	ship=new ShipmentTest();
	scsht=new TakeScreenShot();
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	loginData=ship.getData();
	loginSection.setLoginPageUsrName(loginData[0][0]);
	loginSection.setLoginPagePassword(loginData[0][1]);
	loginSection.clickLoginPageLoginBtn();
	logger.info("Login completed");

	R = new RecruitmentPage(driver);
	driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);	

}	

@Test
public void recruitmentSection() throws InterruptedException
{
	R.candidate(loginData[18][0],loginData[18][1]);
	logger.info("recruitment Section is completed");
}

@AfterTest
public void tearDown() throws Exception
{	Thread.sleep(2000);
	driver.quit();
}
}
